context("Test dependencies")

test_that("checkDependencies", {

checkConditionalAndDependency <- function (configuration, parameters) {
  namesParameters <- names(parameters$conditions)
  for (p in namesParameters) {
     if (!irace:::conditionsSatisfied(parameters, configuration, p)) {
       expect(is.na(configuration[,p]), paste("Conditional parameter", p, 
              "is not active but it has a value",configuration[,p],"assigned."))
     } else {
       if (parameters$isDependent[p]) {
         bounds <- getDependentBound(p, configuration, parameters)
         if (!is.na(bounds$lower))
           expect (configuration[,p] >= bounds$lower, paste("Parameter", p, "=", configuration[,p], 
                  "does not comply with dependency: ", parameters$dependencies[[p]][1],
                  "and lower bound :",bounds$lower))
         if (!is.na(bounds$upper))
           expect (configuration[,p] <= bounds$upper, paste("Parameter", p, "=", configuration[,p], 
                  "does not comply with dependency: ", parameters$dependencies[[p]][2],
                  "and upper bound :", bounds$upper))
       }
     }
  }
}

target.runner <- function(experiment, scenario)
  {
    configuration     <- experiment$configuration
    tmax <-  as.numeric(configuration[["real"]])
    if (configuration[["mode"]] %in% c("x1", "x2"))
      temp <-  as.numeric(configuration[["param1"]])
    else
      temp <- 1
    time <- max(1, abs(rnorm(1, mean=(tmax+temp)/10)))
    return(list(cost = time, time = time, call = toString(experiment)))
  }
  
test.checkDependencies <- function(parameterFile, dependencyFile, ...)
{
  args <- list(...)
  weights <- rnorm(200, mean = 0.9, sd = 0.02)
  parameters <- readParameters(parameterFile, dependencyFile=dependencyFile)
  scenario <- list(targetRunner = target.runner, instances = weights, seed = 1234567, maxExperiments=200)
  scenario <- modifyList(scenario, args)
  scenario <- checkScenario (scenario)
 
  nconf <- 100
  conf <- sampleUniform(parameters, nconf, 4)
  conf <- cbind(seq(1,nrow(conf)), conf)
  names(conf)[1]<- ".ID."

  for (i in 1:nconf)
    checkConditionalAndDependency(conf[i,], parameters)
 
  model <- initialiseModel(parameters, conf, 4)
  conf2 <- sampleModel(parameters, conf, model, nconf, 4)
  for (i in 1:nconf)
    checkConditionalAndDependency(conf2[i,], parameters)

  confs <- irace(scenario = scenario, parameters = parameters)
  for (i in 1:nrow(confs)) {
    checkConditionalAndDependency(confs[1,], parameters)
  } 

}
  test.checkDependencies(parameterFile="parameters.txt", dependencyFile="dependencies.txt")
})

