ln -s ~/Papers/BIB/abbrev.bib abbrev.bib
ln -s ~/Papers/BIB/journals.bib journals.bib
ln -s ~/Papers/BIB/authors.bib authors.bib
ln -s ~/Papers/BIB/biblio.bib biblio.bib
ln -s ~/Papers/BIB/crossref.bib crossref.bib
ln -s ~/Papers/BIB/abbrevshort.bib abbrevshort.bib

